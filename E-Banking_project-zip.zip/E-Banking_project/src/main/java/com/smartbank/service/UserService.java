package com.smartbank.service;

import java.util.List;

import com.smartbank.model.Account;

public interface UserService {

	String loginCheck(String customerID, String password);
	public List <Account> getAccount(String accountID);

}
