package com.smartbank.dao;

import com.smartbank.model.Account;
import java.util.List;

public interface UserDao {
	public String loginCheck(String customerID, String password);
	public List <Account> getAccount(String accountID);

}
