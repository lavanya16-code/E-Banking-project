package com.smartbank.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.smartbank.model.Account;
import com.smartbank.model.UserAccount;

@Repository
public class UserDaoImpl implements UserDao {

	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public String loginCheck(String customerID, String password) {
		
		Session currentSession = sessionFactory.getCurrentSession();
				
		Query theQuery = currentSession.createQuery("from UserAccount u where u.customerID=:id AND u.password=:pwd");
		theQuery.setParameter("id", customerID);
		theQuery.setParameter("pwd", password);

		List results = theQuery.list();
		
		if ((results!=null) && (results.size()>0)){
			return "success";
		}
		else {
		return "failed";
	}
		
}

	@Override
	public List<Account> getAccount(String accountID) {
		
		Session currentSession = sessionFactory.getCurrentSession();
		Query<Account> theQuery = currentSession.createQuery("from Account p where p.accountID=:id", Account.class);
		theQuery.setParameter("id", accountID);
		List<Account> theAccount = theQuery.getResultList();

		return theAccount;
	}
	
}

